from setuptools import setup

setup(
    name='circulo',
    version='1.0',
    description='Es el programa de Alejandro',
    author='David Alejandro Ayala Palacios',
    author_email='dayala@gmail.com',
    url='trello.com/pa',
    py_modules=['circulo'],
)
