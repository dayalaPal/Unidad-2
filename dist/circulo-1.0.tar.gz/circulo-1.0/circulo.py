"""David Alejandro Ayala Palacios"""

def peri(r: float) -> float:
    p = 2 * 3.14 * r
    return p


def area(z: float) -> float:
    a = 3.14 * (z * z)
    return a
